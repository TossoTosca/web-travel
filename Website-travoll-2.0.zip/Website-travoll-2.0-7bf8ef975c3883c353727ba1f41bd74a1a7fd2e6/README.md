# Website-travoll-2.0
belajar membuat web travell dari hacktiv8 .

Saya membuat file readme ini bertujuan untuk memberitahukan progres saya mengenai project yang saya kerjakan.
untuk mengerjakar project ini saya ber inisiatif untuk menyelesaikannya terlebih dahulu daripada harus melanjutkan pembelajaran yang diberikan..
untuk membuat website ini , saya memilih jalan pintas dari youtube untuk mencari cara bagaimana membuat apa yang diminta pada halaman tugas akhir.
lalu ber ekperiment dengan pilihan saya untuk membuat website tersebut.
namun karna terlalu terlena dalam jalan yang saya pilih. 
saya kehabisan waktu dalam pembuatan website ini..
----
## hasil dari website yang dibuat
1.web page responsive (modal box, card,dropdown,total price).
2.togle button active .
--
## yang belum tercapai
1. code syntax belum clean.
2. search box masih perlu perbaikan.
3. web page beberapa masih belum terselesaikan.
--
## copyright
https://getbootstrap.com/
https://www.w3schools.com/
